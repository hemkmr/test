# -*- coding: utf-8 -*-
from scrapy.item import Item, Field

class TItem(Item):
	prodURL = Field()
	prodName = Field()
	prodDesc = Field()
	prodColor = Field()
	prodSize = Field()
	prodPattern = Field()
	prodOldPrice = Field()
	prodNewPrice = Field()
	prodImg1 = Field()
	prodImg2 = Field()
	prodImg3 = Field()
	prodImg4 = Field()
	prodImg5 = Field()
	comBy = Field()
	comDate = Field()
	comTitle = Field()
	comText = Field()
	comLikes = Field()
	comDislikes = Field()
	comRating = Field()