#Import to access system services (filesystem, time, os)
import sys
from os import path
import os, shutil, time
from datetime import datetime, timedelta
#Import for reading excel file
import xlrd
from xlrd import open_workbook
#Importing own created xl program
from t import readExcel
#Import for writing output to CSV file
import csv
#Import for working/parsing URLs in Python
from urlparse import urlparse
#Imports for Scrapy
import scrapy
from t.items import *
from t.spider import CommonSpider
from scrapy.selector import Selector
from scrapy.contrib.loader import ItemLoader
from scrapy.spiders import CrawlSpider, Rule
from scrapy.contrib.exporter import CsvItemExporter
from scrapy.linkextractors import LinkExtractor as sle
from scrapy.contrib.loader.processor import TakeFirst, Join, MapCompose

#Setting variables to be used later in the script
xlFileName = r'crawlerInput.xls'
#Reading values from excel file
sitesToCrawl = readExcel.getValues(xlFileName)
#Associating declared items to be captured with the ones being used in script
itemRow = TItem()

for xlItem in sitesToCrawl:
	#Parsing URL retrieve from excel for scheme, host, port
	urlToCrawl = urlparse(xlItem.siteURL)
	print 'Excel Row Locator(s)\nCrawl URL: '+xlItem.siteURL+'\nLocator Type: '+xlItem.locatorType+'\nParent Container: '+xlItem.parentContainer+'\nName: '+xlItem.prodName+'\nOld Price: '+xlItem.prodOldPrice+'\nNew Price: '+xlItem.prodNewPrice
	#Checking for blanks in input excel and handling them
	if (xlItem.siteURL == "" or xlItem.parentContainer == "" or xlItem.prodName == "" or xlItem.prodOldPrice == "" or xlItem.prodNewPrice == "" or xlItem.prodImg1 == "" or xlItem.prodDesc == "" or xlItem.prodColor == "" or xlItem.prodPattern == "" or xlItem.prodSize == "" or xlItem.prodImg2 == "" or xlItem.prodImg3 == "" or xlItem.prodImg4 == "" or xlItem.prodImg5 == "" or xlItem.comBy == "" or xlItem.comDate == "" or xlItem.comTitle == "" or xlItem.comText == "" or xlItem.comLikes == "" or xlItem.comDislikes == "" or xlItem.comRating == ""):
		print "\nBlank selector provided for "+urlToCrawl.geturl()+" aborting and moving to next row!!"
		urlToCrawl = ""
		continue
	class wensilSpider1(CommonSpider):
		name = 't'
		allowed_domains = [urlToCrawl.netloc, urlToCrawl.netloc]
		start_urls = [urlToCrawl.geturl()]
		#Setting rules to filter URLs to crawl/scrap 
		rules = [ Rule(sle(allow=(".*")), callback='parse_12', follow=True) ]
		#Setting the Name of output CSV file as "time_hostname.csv"
		outPutFl = time.strftime("%d%m%Y-%H%M%S")+"_"+(urlToCrawl.hostname).split(".")[1]+'.csv'
		def parse_12(self, response):
			self.logger.info("\nCrawling HOST: "+(urlToCrawl.hostname).split(".")[1])
			#Extracting and storing item details to items of items class
			itemRow['prodURL'] = response.url
			if xlItem.locatorType == 'XPath':
				self.logger.info("\nLocator Type is: "+xlItem.locatorType)
				itemRow['prodName'] = response.xpath(xlItem.prodName).extract()
				itemRow['prodDesc'] = response.xpath(xlItem.prodDesc).extract()
				itemRow['prodColor'] = response.xpath(xlItem.prodColor).extract()
				itemRow['prodSize'] = response.xpath(xlItem.prodSize).extract()
				itemRow['prodPattern'] = response.xpath(xlItem.prodPattern).extract()
				itemRow['prodOldPrice'] = response.xpath(xlItem.prodOldPrice).extract()
				itemRow['prodNewPrice'] = response.xpath(xlItem.prodNewPrice).extract()
				itemRow['prodImg1'] = response.xpath(xlItem.prodImg1).extract()
				itemRow['prodImg2'] = response.xpath(xlItem.prodImg2).extract()
				itemRow['prodImg3'] = response.xpath(xlItem.prodImg3).extract()
				itemRow['prodImg4'] = response.xpath(xlItem.prodImg4).extract()
				itemRow['prodImg5'] = response.xpath(xlItem.prodImg5).extract()
				itemRow['comBy'] = response.xpath(xlItem.comBy).extract()
				itemRow['comDate'] = response.xpath(xlItem.comDate).extract()
				itemRow['comTitle'] = response.xpath(xlItem.comTitle).extract()
				itemRow['comText'] = response.xpath(xlItem.comText).extract()
				itemRow['comLikes'] = response.xpath(xlItem.comLikes).extract()
				itemRow['comDislikes'] = response.xpath(xlItem.comDislikes).extract()
				itemRow['comRating'] = response.xpath(xlItem.comRating).extract()
			elif xlItem.locatorType == 'CSS':
				self.logger.info("\nLocator Type is: "+xlItem.locatorType)
				itemRow['prodName'] = response.css(xlItem.prodName).extract()
				itemRow['prodDesc'] = response.css(xlItem.prodDesc).extract()
				itemRow['prodColor'] = response.css(xlItem.prodColor).extract()
				itemRow['prodSize'] = response.css(xlItem.prodSize).extract()
				itemRow['prodPattern'] = response.css(xlItem.prodPattern).extract()
				itemRow['prodOldPrice'] = response.css(xlItem.prodOldPrice).extract()
				itemRow['prodNewPrice'] = response.css(xlItem.prodNewPrice).extract()
				itemRow['prodImg1'] = response.css(xlItem.prodImg1).extract()
				itemRow['prodImg2'] = response.css(xlItem.prodImg2).extract()
				itemRow['prodImg3'] = response.css(xlItem.prodImg3).extract()
				itemRow['prodImg4'] = response.css(xlItem.prodImg4).extract()
				itemRow['prodImg5'] = response.css(xlItem.prodImg5).extract()
				itemRow['comBy'] = response.css(xlItem.comBy).extract()
				itemRow['comDate'] = response.css(xlItem.comDate).extract()
				itemRow['comTitle'] = response.css(xlItem.comTitle).extract()
				itemRow['comText'] = response.css(xlItem.comText).extract()
				itemRow['comLikes'] = response.css(xlItem.comLikes).extract()
				itemRow['comDislikes'] = response.css(xlItem.comDislikes).extract()
				itemRow['comRating'] = response.css(xlItem.comRating).extract()				
			else:
				self.logger.info("\nINVALID Locator!! "+xlItem.locatorType)
			yield itemRow