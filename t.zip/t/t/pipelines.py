# -*- coding: utf-8 -*-
import csv
import codecs
import os, shutil, time
from scrapy import signals
from t.items import *
from collections import OrderedDict
from scrapy.exceptions import DropItem
from datetime import datetime, timedelta
from scrapy.contrib.exporter import CsvItemExporter

class DropIfEmptyFieldPipeline(object):
	def process_item(self, item, spider):
		if not(all(item.values())):
			print "\n\r{0}".format("-"*80)
			print 'ITEM DROPPED! due to any value being NULL'
			print item
			print "\n\r{0}".format("-"*80)		
			raise DropItem()
		elif not (item['prodURL'] == "" and item['prodName'] == "" and item['prodOldPrice'] == "" and item['prodNewPrice'] == "" and item['prodImg1'] == ""):
			print "\n\r{0}".format("-"*80)
			print 'ITEM DROPPED! Missing mandatory values'
			print item
			print "\n\r{0}".format("-"*80)		
			raise DropItem()			
		else:
			return item

class TPipeline(object):
	def process_item(self, item, spider):
		return item

class csvPipeline(object):
	@classmethod
	def from_crawler(cls, crawler):
		pipeline = cls()
		crawler.signals.connect(pipeline.spider_opened, signals.spider_opened)
		crawler.signals.connect(pipeline.spider_closed, signals.spider_closed)
		return pipeline
	
	def spider_opened(self, spider):
		self.file = open(time.strftime("%d%m%Y-%H%M%S_")+spider.name+'_CrawedData.csv', 'w+b')
		self.exporter = CsvItemExporter(self.file)
		self.exporter.fields_to_export = ['prodURL', 'prodName', 'prodDesc', 'prodColor', 'prodSize', 'prodPattern', 'prodOldPrice', 'prodNewPrice', 'prodImg1', 'prodImg2', 'prodImg3', 'prodImg4', 'prodImg5', 'comBy', 'comDate', 'comTitle', 'comText', 'comLikes', 'comDislikes', 'comRating']
		self.exporter.start_exporting()

	def spider_closed(self, spider):
		self.exporter.finish_exporting()
		self.file.close()

	def process_item(self, item, spider):
		if not (item['prodURL'] == "" and item['prodName'] == "" and item['prodOldPrice'] == "" and item['prodNewPrice'] == "" and item['prodImg1'] == ""):
			self.exporter.export_item(item)
			return item