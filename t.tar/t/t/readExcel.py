from xlrd import open_workbook
xlFileName = r'C:\Users\hemant\Desktop\crawlerInput.xls'

class readExcel(object):
	def __init__(self, siteURL, locatorType, parentContainer, prodName, prodDesc, prodColor, prodPattern, prodSize, prodOldPrice, prodNewPrice, prodImg1, prodImg2, prodImg3, prodImg4, prodImg5, comBy, comDate, comTitle, comText, comLikes, comDislikes, comRating):
		self.siteURL = siteURL
		self.locatorType = locatorType
		self.parentContainer = parentContainer
		self.prodName = prodName
		self.prodDesc = prodDesc
		self.prodColor = prodColor
		self.prodPattern = prodPattern
		self.prodSize = prodSize
		self.prodOldPrice = prodOldPrice
		self.prodNewPrice = prodNewPrice
		self.prodImg1 = prodImg1
		self.prodImg2 = prodImg2
		self.prodImg3 = prodImg3
		self.prodImg4 = prodImg4
		self.prodImg5 = prodImg5
		self.comBy = comBy
		self.comDate = comDate
		self.comTitle = comTitle
		self.comText = comText
		self.comLikes = comLikes
		self.comDislikes = comDislikes
		self.comRating = comRating
	def __str__(self):
		return("readXL:\n"
				"  siteURL = {0}\n"
				"  locatorType = {1}\n"
				"  parentContainer = {2}\n"				
				"  prodName = {3}\n"
				"  prodDesc = {4}\n"
				"  prodColor = {5}\n"
				"  prodPattern = {6}\n"
				"  prodSize = {7}\n"
				"  prodOldPrice = {8}\n"
				"  prodNewPrice = {9}\n"
				"  prodImg1 = {10}\n"
				"  prodImg2 = {11}\n"
				"  prodImg3 = {12}\n"
				"  prodImg4 = {13}\n"
				"  prodImg5 = {14}\n"
				"  comBy = {15}\n"
				"  comDate = {16}\n"	
				"  comTitle = {17}\n"
				"  comText = {18}\n"
				"  comLikes = {19}\n"
				"  comDislikes = {20}\n"
				"  comRating = {21}\n"				
				.format(self.siteURL, self.locatorType, self.parentContainer, self.prodName, self.prodDesc, self.prodColor,
					self.prodPattern, self.prodSize, self.prodOldPrice, self.prodNewPrice, self.prodImg1, self.prodImg2, self.prodImg3, self.prodImg4, self.prodImg5, self.comURL, self.comBy, self.comDate, self.comTitle, self.comText, self.comLikes, self.comDislikes, self.comRating))

def getValues(xlFileName):
	wb = open_workbook(xlFileName)
	for sheet in wb.sheets():
		number_of_rows = sheet.nrows
		number_of_columns = sheet.ncols
		print "Excel file "+xlFileName+" has "+str(number_of_rows)+" Rows and "+str(number_of_columns)+" Columns"
		xlitems = []
		rows = []
		for row in range(1, number_of_rows):
			values = []
			for col in range(0, number_of_columns):
				value  = (sheet.cell(row,col).value)
				try:
					value = str(int(value))
				except ValueError:
					pass
				finally:
					values.append(value)
			item = readExcel(*values)
			xlitems.append(item)
		return xlitems